create trigger TESTDOMAIN_TRIGGER
	before insert
	on TESTAPPP_TESTDOMAIN
	for each row
begin
select testdomain_seq.nextval into :new.id from dual;
end;