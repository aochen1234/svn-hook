create trigger TESTSET_TRIGGER
	before insert
	on TESTAPPP_TESTSET
	for each row
begin
select testset_seq.nextval into :new.id from dual;
end;