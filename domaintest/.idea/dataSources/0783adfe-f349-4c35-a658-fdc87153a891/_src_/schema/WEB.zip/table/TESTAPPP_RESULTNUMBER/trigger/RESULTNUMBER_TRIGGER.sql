create trigger RESULTNUMBER_TRIGGER
	before insert
	on TESTAPPP_RESULTNUMBER
	for each row
begin
select resultnumber_seq.nextval into :new.id from dual;
end;