create trigger DJANGO_MIGRATIONS_TR
	before insert
	on DJANGO_MIGRATIONS
	for each row
BEGIN
        SELECT "DJANGO_MIGRATIONS_SQ".nextval
        INTO :new."ID" FROM dual;
    END;
