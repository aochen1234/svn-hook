create trigger TESTAPPP_NEWUSER_GROUPS_TR
	before insert
	on TESTAPPP_NEWUSER_GROUPS
	for each row
BEGIN
        SELECT "TESTAPPP_NEWUSER_GROUPS_SQ".nextval
        INTO :new."ID" FROM dual;
    END;
