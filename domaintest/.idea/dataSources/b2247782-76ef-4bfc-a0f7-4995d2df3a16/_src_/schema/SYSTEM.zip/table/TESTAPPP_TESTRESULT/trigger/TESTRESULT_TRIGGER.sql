create trigger TESTRESULT_TRIGGER
	before insert
	on TESTAPPP_TESTRESULT
	for each row
begin
    select testresult_seq.nextval into :new.id from dual;
    end;