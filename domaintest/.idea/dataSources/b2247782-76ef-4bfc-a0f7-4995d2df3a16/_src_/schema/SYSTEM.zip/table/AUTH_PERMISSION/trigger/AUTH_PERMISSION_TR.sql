create trigger AUTH_PERMISSION_TR
	before insert
	on AUTH_PERMISSION
	for each row
BEGIN
        SELECT "AUTH_PERMISSION_SQ".nextval
        INTO :new."ID" FROM dual;
    END;
