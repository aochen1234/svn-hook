create trigger SECONDDATA_TRIGGER
	before insert
	on SECONDDATA
	for each row
begin
select seconddata_seq.nextval into :new.id from dual;
end;
