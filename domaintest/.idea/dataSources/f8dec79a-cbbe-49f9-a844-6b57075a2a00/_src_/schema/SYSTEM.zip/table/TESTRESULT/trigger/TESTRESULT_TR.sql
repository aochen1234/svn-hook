create trigger TESTRESULT_TR
	before insert
	on TESTRESULT
	for each row
BEGIN
        SELECT "TESTRESULT_SQ".nextval
        INTO :new."ID" FROM dual;
    END;
