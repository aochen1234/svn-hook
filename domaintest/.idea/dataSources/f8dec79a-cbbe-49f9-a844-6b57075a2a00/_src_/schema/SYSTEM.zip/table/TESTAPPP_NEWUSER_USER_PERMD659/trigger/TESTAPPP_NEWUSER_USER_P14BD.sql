create trigger TESTAPPP_NEWUSER_USER_P14BD
	before insert
	on TESTAPPP_NEWUSER_USER_PERMD659
	for each row
BEGIN
        SELECT "TESTAPPP_NEWUSER_USER_P12BE".nextval
        INTO :new."ID" FROM dual;
    END;
