create trigger TESTAPPP_NEWUSER_TR
	before insert
	on TESTAPPP_NEWUSER
	for each row
BEGIN
        SELECT "TESTAPPP_NEWUSER_SQ".nextval
        INTO :new."ID" FROM dual;
    END;
