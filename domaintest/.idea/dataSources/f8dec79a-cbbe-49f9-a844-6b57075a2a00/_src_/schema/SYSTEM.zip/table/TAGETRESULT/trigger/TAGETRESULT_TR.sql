create trigger TAGETRESULT_TR
	before insert
	on TAGETRESULT
	for each row
BEGIN
        SELECT "TAGETRESULT_SQ".nextval
        INTO :new."ID" FROM dual;
    END;
