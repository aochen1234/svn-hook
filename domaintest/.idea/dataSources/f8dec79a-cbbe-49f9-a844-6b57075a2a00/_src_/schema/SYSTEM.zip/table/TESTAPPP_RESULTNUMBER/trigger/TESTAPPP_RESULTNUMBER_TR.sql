create trigger TESTAPPP_RESULTNUMBER_TR
	before insert
	on TESTAPPP_RESULTNUMBER
	for each row
BEGIN
        SELECT "TESTAPPP_RESULTNUMBER_SQ".nextval
        INTO :new."ID" FROM dual;
    END;
