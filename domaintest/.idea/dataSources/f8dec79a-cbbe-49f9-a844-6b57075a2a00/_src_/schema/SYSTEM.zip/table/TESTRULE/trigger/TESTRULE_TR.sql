create trigger TESTRULE_TR
	before insert
	on TESTRULE
	for each row
BEGIN
        SELECT "TESTRULE_SQ".nextval
        INTO :new."ID" FROM dual;
    END;
